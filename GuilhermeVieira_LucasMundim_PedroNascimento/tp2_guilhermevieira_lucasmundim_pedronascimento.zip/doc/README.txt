ARQUIVOS EXTRAS INCLUSOS:
-> Foram inclusos, conforme consta na documentação, os ScreenShots em resolução original do CPUSim, na pasta doc/ScreenShots, conforme documentado