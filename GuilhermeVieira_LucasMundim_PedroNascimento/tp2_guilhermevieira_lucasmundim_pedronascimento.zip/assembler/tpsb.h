#ifndef _TPSB_H_
#define _TPSB_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "conversor.h"
#include "lista.h"
#include "assembler.h"

#endif
