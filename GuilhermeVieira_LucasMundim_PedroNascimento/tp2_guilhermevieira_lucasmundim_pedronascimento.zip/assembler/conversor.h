#ifndef _CONVERSOR_H_
#define _CONVERSOR_H_

char* convertNumber(int number, int bits);

#endif
